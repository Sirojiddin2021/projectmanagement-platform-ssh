import os
import validators

#from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from flask_mail import Mail, Message
from itsdangerous import URLSafeTimedSerializer, SignatureExpired


from flask_wtf.csrf import CSRFProtect

from initialization import *    #init, engine, Users

from table_forms import RegForm, LoginForm, AddInfo

from sqlalchemy.sql import text, column
from sqlalchemy import update, or_

from sqlalchemy.orm import sessionmaker, relationship
from helpers import apology, login_required, lookup, usd

# to get current date and time
from datetime import datetime

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.config['SECRET_KEY'] = 'any secret string'

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.config["SECRET_KEY"] = 'Thisissecret'
CSRFProtect(app)
Session(app)



# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")



SessionDB=sessionmaker(bind=engine)
dbsession = SessionDB()


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    # Forget any user_id
    session.clear()
    form = LoginForm()

    if form.validate_on_submit():
        user = dbsession.query(Users).filter(or_(Users.Username==form.username.data, Users.Email==form.username.data)).first()

        if user:
            if check_password_hash(user.Password, form.password.data):

                session["user_id"] = user.Id
                return redirect("/home")
        return apology('Invalid username or pasword')

    return render_template("user/login.html", form=form)


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register new user"""

    form = RegForm()
    if form.validate_on_submit():

        user = Users(
            Username = form.username.data,
            Password = generate_password_hash(form.password.data),
            Email = form.email.data
            )

        dbsession.add(user)
        dbsession.commit()
        query = dbsession.query(Users.Id).filter_by(Username=form.username.data).first()
        session["user_id"] = query.Id
        flash("Registered!")

        return redirect("/userinfo")
    else:
        apology('Invalid fields', 400)


    return render_template("/user/register.html", form=form)

@app.route("/userinfo", methods=["GET", "POST"])
@login_required
def userinfo():
    """ User update function """

    form = AddInfo()
    user = dbsession.query(Users).filter_by(Id=session["user_id"]).first()

    if form.validate_on_submit():

        user.Firstname = form.firstname.data
        user.Lastname = form.lastname.data
        user.Role = form.role.data
        user.Phone = form.phone.data
        user.Rate = form.rate.data
        user.About = form.about.data
        user.Project_manager = form.pm.data

        dbsession.commit()
        session["user_id"] = user.Id
        return redirect("/home")

    return render_template("/user/info.html", form=form, userdata=user)

@app.route("/home", methods=["GET", "POST"])
@login_required
def home():
    """ home page """


    return render_template("user/home.html")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""
    return render_template("index.html")

@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")

@app.route("/addsection")
@login_required
def addsection():
    """ add sections """
    return render_template("user/projects/edit/addsection.html", form=form)

def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)